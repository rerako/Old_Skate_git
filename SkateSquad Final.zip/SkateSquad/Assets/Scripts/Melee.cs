﻿using UnityEngine;
using System.Collections;

public class Melee : MonoBehaviour {
    RaycastHit hit;
    float distance;
    public Animation swing;

	void FixedUpdate () {

        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Input.GetButtonDown("Fire1"))
        {

            swing.Play("melee");
            if (Physics.Raycast(ray, out hit, 4))
            {
                if (hit.collider.gameObject.tag.Equals("Target"))
                {
                    Destroy(hit.collider.gameObject);
                }
            }

        }
    }
}
