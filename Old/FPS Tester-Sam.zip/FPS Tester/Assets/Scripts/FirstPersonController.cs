﻿using UnityEngine;
using System.Collections;

[RequireComponent (typeof(CharacterController))]
public class FirstPersonController : MonoBehaviour {

    public float movementSpeed = 0.0f;
    public float minSpeed = 0.0f;
    public float maxSpeed = 0.0f;
    public float moveRate = 0.0f;
    public float jumpSpeed = 0.0f;

    public float mouseSens = 0.0f;
    float verRotate = 0;
    public float upDownRange = 0.0f;

    float verVelocity = 0;
    public CharacterController cc;


    // Use this for initialization
    void Start () {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        cc = GetComponent<CharacterController>();
        movementSpeed = minSpeed;
    }
	
	// Update is called once per frame
	void FixedUpdate () {


        // Rotation
        float rotLeftRight = Input.GetAxis("Mouse X") * mouseSens;
        transform.Rotate(0, rotLeftRight, 0);

        verRotate -= Input.GetAxis("Mouse Y") * mouseSens;
        verRotate = Mathf.Clamp(verRotate, -upDownRange, upDownRange);
        Camera.main.transform.localRotation = Quaternion.Euler(verRotate, 0 , 0);

        // Movement
        float forwardSpeed;
        if(Input.GetButton("Vertical"))
        {
            if (movementSpeed < maxSpeed)
            {
                movementSpeed += moveRate;
            }
            

            
        }
        else
        {
            if (movementSpeed > minSpeed)
            {
                movementSpeed -= moveRate;
            }
            
        }

        forwardSpeed = movementSpeed;

        float sideSpeed = Input.GetAxis("Horizontal") * movementSpeed;

        verVelocity += (Physics.gravity.y) * Time.deltaTime;

        //Jump
        if (cc.isGrounded && Input.GetButton("Jump"))
        {
            verVelocity = jumpSpeed;
        }

        Vector3 speed = new Vector3(sideSpeed, verVelocity, forwardSpeed);
        speed = transform.rotation * speed;



        cc.Move(speed* Time.fixedDeltaTime);

    }
}
