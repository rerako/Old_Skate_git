﻿using UnityEngine;
using System.Collections;

[RequireComponent (typeof(CharacterController))]
public class FirstPersonController : MonoBehaviour {

    public float movementSpeed = 10.0f;
    public float mouseSens = 5.0f;
    public float jumpSpeed = 20.0f;

    float verRotate = 0;
    public float upDownRange = 60.0f;

    float verVelocity = 0;
    public CharacterController cc;
    

    // Use this for initialization
    void Start () {
        Screen.lockCursor = true;
        cc = GetComponent<CharacterController>();
    }
	
	// Update is called once per frame
	void Update () {


        // Rotation
        float rotLeftRight = Input.GetAxis("Mouse X") * mouseSens;
        transform.Rotate(0, rotLeftRight, 0);

        verRotate -= Input.GetAxis("Mouse Y") * mouseSens;
        verRotate = Mathf.Clamp(verRotate, -upDownRange, upDownRange);
        Camera.main.transform.localRotation = Quaternion.Euler(verRotate, 0 , 0);

        // Movement
        float forwardSpeed = Input.GetAxis("Vertical") * movementSpeed;
        float sideSpeed = Input.GetAxis("Horizontal") * movementSpeed;

        verVelocity += (Physics.gravity.y * 2) * Time.deltaTime;

            //Jump
        if( cc.isGrounded && Input.GetButton("Jump") )
        {
            verVelocity = jumpSpeed;
        }

        Vector3 speed = new Vector3(sideSpeed, verVelocity, forwardSpeed);
        speed = transform.rotation * speed;



        cc.Move(speed * Time.deltaTime);



    }
}
