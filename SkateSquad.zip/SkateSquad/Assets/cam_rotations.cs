﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cam_rotations : MonoBehaviour
{
    camScript grabCam;
    public GameObject cam;
    bool freecam;
    public Vector3 euler_Look;

    public float mouseSensitivity = 100.0f;
    public float clampAngle = 60.0f;
    public bool lookmode;
    public float rotY = 0.0f; // rotation around the up/y axis
    public float rotX = 0.0f; // rotation around the right/x axis
    public float stockx;
    public float stocky;
    public Quaternion localRotation2;
    public Quaternion localRotation;
    // Use this for initialization
    void Start()
    {
        Vector3 rot = transform.localRotation.eulerAngles;
        rotY = rot.y;
        rotX = rot.x;
        grabCam = gameObject.GetComponent<camScript>();
    }

    // Update is called once per frame
    void Update()
    {
        cam = grabCam.GiveCam();
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = -Input.GetAxis("Mouse Y");
        rotY += mouseX * mouseSensitivity * Time.deltaTime;
        rotX += mouseY * mouseSensitivity * Time.deltaTime;
        rotX = Mathf.Clamp(rotX, -clampAngle , clampAngle);
        //rotY = Mathf.Clamp(rotY, -clampAngle, clampAngle);


        //if holding right click it turns on look mode and turns off camera follow for player angle
        if (Input.GetMouseButton(1)) {
            // stores angle when right click happens
            if (!lookmode) {
                euler_Look = cam.transform.eulerAngles;
                stockx = rotX;
                stocky = rotY;

                lookmode = true;
            }
            localRotation = Quaternion.Euler(rotX, rotY, 0.0f);
            cam.transform.rotation = localRotation;

        }
        //camera checks for X,Y axis changes
        //player object checks forY axis changes
        else
        {
            localRotation2 = Quaternion.Euler(0.0f, rotY, 0.0f);
            localRotation = Quaternion.Euler(rotX, rotY, 0.0f);
            gameObject.transform.rotation = localRotation2;
            cam.transform.rotation = localRotation;
        }
        //when you let go of right click, it restores the angle back to the original spot when it was first pressed.
        if (Input.GetMouseButtonUp(1))
        {
            //cam.transform.eulerAngles = euler_Look;
            //gameObject.transform.eulerAngles = euler_Look;
            rotX = stockx;
            rotY = stocky;
           lookmode = false;
        }

    }

}
