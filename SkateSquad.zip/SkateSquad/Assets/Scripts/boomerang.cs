﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boomerang : MonoBehaviour {
    public Transform player;
    public float force;
    public float Timer;
    public bool one_Use;
    // Use this for initialization
    void Start () {
		if(Timer < 0)
        {
            Timer = 3f;
        }
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 normalize = Vector3.Normalize(player.position - transform.position);
        gameObject.GetComponent<Rigidbody>().AddForce(normalize * force * Time.deltaTime);
        Timer -= Time.deltaTime;
        if(one_Use && Timer < 0)
        {
            DestroyObject(gameObject);
        }
	}
    public void setTarg(Transform pos) {

        player = pos;
    }
    void OnCollisionEnter(Collision poke)
    {
        if (poke.gameObject.CompareTag("Player"))
        {
            DestroyObject(gameObject);
        }
        if (poke.gameObject.CompareTag("Target"))
        {
            DestroyObject(poke.gameObject);

        }
    }
}
